in server.php: Replace the hardcoded user ID with session management to store the logged-in user's ID. I have
already provided the updated server.php code in my previous response here. Please use that code to replace the existing server.php.
After making these changes, your application should work as expected. Remember to replace the placeholders your_username,
 your_password, and your_database in the server.php file with your actual database credentials.
